import {publicMapConfig} from './maps.mjs';
import { validateIdentity } from '../web/identity.mjs';
import { accounts } from './accounts.mjs';
import { marketplace } from './market.mjs';
import { randomBytes, randomUUID, randomInt, createHash, createHmac, timingSafeEqual, createCipheriv, createDecipheriv } from 'node:crypto';
import { normalizePhone } from '../web/core.mjs';
import { validateTransport, feeKobo, actionFor, custodyAfter, flowPublic } from '../web/lifecycle.mjs';
import { providersFromEnv, ProviderError } from './providers.mjs';
const digest = s => createHash('sha256').update(s).digest('hex');
const token = () => randomBytes(32).toString('hex');
const tokenPattern = /^[a-f0-9]{64}$/;
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const fail = (message, status = 400) => {
  throw new ProviderError(message, status);
};
function equal(a, b) {
  const x = Buffer.from(String(a)),
    y = Buffer.from(String(b));
  return x.length === y.length && timingSafeEqual(x, y);
}
export async function operations(db, {
  owner,
  body,
  providers = providersFromEnv(),
  env = process.env
} = {}) {
  await db.exec(`CREATE TABLE IF NOT EXISTS auth_challenges(id TEXT PRIMARY KEY,phone TEXT,salt TEXT,hash TEXT,expires INTEGER,attempts INTEGER DEFAULT 0,used INTEGER DEFAULT 0,created INTEGER);
 CREATE TABLE IF NOT EXISTS rider_sessions(token_hash TEXT PRIMARY KEY,rider_id TEXT,expires INTEGER);
 CREATE TABLE IF NOT EXISTS rider_profiles(id TEXT PRIMARY KEY,phone TEXT UNIQUE,display_name TEXT,identity_cipher TEXT,identity_status TEXT DEFAULT 'missing',recipient_code TEXT);
 CREATE TABLE IF NOT EXISTS job_tokens(token_hash TEXT PRIMARY KEY,shipment_id TEXT,leg TEXT);
 CREATE TABLE IF NOT EXISTS delivery_proofs(shipment_id TEXT PRIMARY KEY,salt TEXT,hash TEXT,expires INTEGER,attempts INTEGER DEFAULT 0,used INTEGER DEFAULT 0);
 CREATE TABLE IF NOT EXISTS payments(reference TEXT PRIMARY KEY,shipment_id TEXT,amount INTEGER,mode TEXT,status TEXT,provider_id TEXT,created INTEGER);
 CREATE TABLE IF NOT EXISTS earnings(id TEXT PRIMARY KEY,shipment_id TEXT,leg TEXT,rider_id TEXT,amount INTEGER,mode TEXT,status TEXT,transfer_ref TEXT UNIQUE,UNIQUE(shipment_id,leg));`);
  if(!(await db.prepare('PRAGMA table_info(earnings)').all()).some(c=>c.name==='created'))await db.exec('ALTER TABLE earnings ADD COLUMN created INTEGER NOT NULL DEFAULT 0');
  const publicOrigin = env.TRACKSHIP_PUBLIC_URL || env.RENDER_EXTERNAL_URL || '';
  const encryptionKey = () => {
    const raw = env.TRACKSHIP_IDENTITY_KEY || '';
    if (raw.length < 32) fail('Secure identity encryption is not configured.', 503);
    return /^[a-f0-9]{64}$/.test(raw) ? Buffer.from(raw, 'hex') : createHash('sha256').update(raw).digest();
  };
  if (!(await db.prepare('PRAGMA table_info(payments)').all()).some(c => c.name === 'checkout_url')) await db.exec('ALTER TABLE payments ADD COLUMN checkout_url TEXT');
  const getShipment = async id => {
    const row = await db.prepare('SELECT payload FROM shipments WHERE id=?').get(id);
    return row ? JSON.parse(row.payload) : null;
  };
  const putShipment = async s => await db.prepare('UPDATE shipments SET payload=? WHERE id=?').run(JSON.stringify(s), s.id);
  async function transaction(fn) {
    await db.exec('BEGIN IMMEDIATE');
    try {
      const result = await fn();
      await db.exec('COMMIT');
      return result;
    } catch (e) {
      await db.exec('ROLLBACK');
      throw e;
    }
  }
  async function rider(req) {
    const raw = req.headers.authorization?.match(/^Bearer ([a-f0-9]{64})$/)?.[1];
    if (!raw) fail('Verify your rider phone number to continue.', 401);
    const session = await db.prepare('SELECT rider_id,expires FROM rider_sessions WHERE token_hash=?').get(digest(raw));
    if (!session || session.expires < Date.now()) fail('Rider sign-in expired. Verify your phone again.', 401);
    return {
      ...(await db.prepare('SELECT * FROM rider_profiles WHERE id=?').get(session.rider_id)),
      sessionHash: digest(raw)
    };
  }
  async function job(raw) {
    const j = tokenPattern.test(raw) ? await db.prepare('SELECT shipment_id,leg FROM job_tokens WHERE token_hash=?').get(digest(raw)) : null;
    if (!j) fail('Dispatch link not found.', 404);
    const s = await getShipment(j.shipment_id);
    if (!s) fail('Shipment not found.', 404);
    return {
      s,
      leg: j.leg
    };
  }
  function jobView(s, leg) {
    const {
      jobTokens,
      publicToken,
      riderToken,
      location,
      locationConsent,
      dirty,
      synced,
      ...rest
    } = s;
    return {
      ...rest,
      jobLeg: leg,
      locationSharing: Boolean(locationConsent),
      location: s.location?.leg === leg ? s.location : null
    };
  }
  function safeRider(r) {
    return {
      id: r.id,
      phone: r.phone,
      displayName: r.display_name,
      identityStatus: r.identity_status,
      payoutAccountConnected: Boolean(r.recipient_code)
    };
  }
  function append(s, status, leg, actor, note = '') {
    return {
      ...s,
      status,
      custodian: custodyAfter(status, s.deliveryType),
      events: [...s.events, {
        id: randomUUID(),
        status,
        leg,
        actorName: actor?.display_name || s.business,
        note,
        at: new Date().toISOString()
      }],
      location: status === 'Delivered' || custodyAfter(status, s.deliveryType) !== s.custodian ? null : s.location,
      locationConsent: status === 'Delivered' || custodyAfter(status, s.deliveryType) !== s.custodian ? null : s.locationConsent
    };
  }
  const capabilities = () => ({
    maps:publicMapConfig(env),
    service: 'trackship-ng',
    version: '0.6.0',
    payments: providers.paymentReady,
    paymentMode: providers.paymentReady ? providers.mode : null,
    sms: providers.smsReady,
    identity: providers.identityReady,
    publicUrl: publicOrigin || null,
    payouts: env.TRACKSHIP_ENABLE_PAYOUTS === 'true'
  });
  async function verifyFunding(reference, result) {
    const row = await db.prepare('SELECT * FROM payments WHERE reference=?').get(reference);
    if (!row) fail('Payment reference not found.', 404);
    if (typeof result.id !== 'number' || !Number.isSafeInteger(result.id) || result.id <= 0 || result.status !== 'success' || result.reference !== reference || result.currency !== 'NGN' || result.amount !== row.amount || result.domain !== row.mode) fail('Payment was not confirmed for the expected amount, currency and environment.', 409);
    return await transaction(async () => {
      const current = await db.prepare('SELECT * FROM payments WHERE reference=?').get(reference);
      if (current.status === 'paid') return await getShipment(current.shipment_id);
      const s = await getShipment(current.shipment_id);
      if (s.payment.status === 'paid' && s.payment.reference !== reference) fail('This shipment already has a confirmed payment. Contact support about the duplicate charge.', 409);
      await db.prepare('UPDATE payments SET status=?,provider_id=? WHERE reference=?').run('paid', String(result.id), reference);
      const updated = {
        ...s,
        payment: {
          status: 'paid',
          mode: current.mode,
          reference,
          amount: current.amount,
          paidAt: new Date().toISOString()
        }
      };
      await putShipment(updated);
      return updated;
    });
  }
  async function creditEarnings(s) {
    for (const [leg, actor] of Object.entries(s.actors || {})) {
      const amount = s.fees[leg];
      if (!amount) continue;
      await db.prepare('INSERT OR IGNORE INTO earnings(id,shipment_id,leg,rider_id,amount,mode,status,created) VALUES (?,?,?,?,?,?,?,?)').run(randomUUID(), s.id, leg, actor.id, amount, s.payment.mode, s.payment.mode === 'test' ? 'test' : 'available',Date.now());
    }
  }
  async function payoutEntry(entry) {
    if (env.TRACKSHIP_ENABLE_PAYOUTS !== 'true' || entry.mode !== 'live' || entry.status !== 'available') return;
    const r = await db.prepare('SELECT * FROM rider_profiles WHERE id=?').get(entry.rider_id);
    if (r?.identity_status !== 'approved' || !r.recipient_code) return;
    const ref = 'TS-PAYOUT-' + entry.id.replaceAll('-', '');
    const updated = await db.prepare("UPDATE earnings SET status='processing',transfer_ref=? WHERE id=? AND status='available'").run(ref, entry.id);
    if (!updated.changes) return;
    try {
      const result = await providers.transfer({
        source: 'balance',
        amount: entry.amount,
        recipient: r.recipient_code,
        reference: ref,
        reason: 'SendRack completed delivery ' + entry.shipment_id
      });
      if (result.reference !== ref || result.amount !== entry.amount || (typeof result.recipient === 'string' ? result.recipient : result.recipient?.recipient_code) !== r.recipient_code) throw new Error();
      await db.prepare('UPDATE earnings SET status=? WHERE id=?').run(result.status === 'success' ? 'paid' : 'processing', entry.id);
    } catch {/* An ambiguous provider outcome stays processing until webhook/reconciliation. Never blindly transfer twice. */}
  }
  async function autoPayout(s) {
    for (const e of await db.prepare('SELECT * FROM earnings WHERE shipment_id=?').all(s.id)) await payoutEntry(e);
  }
  function decrypt(r) {
    const key = encryptionKey();
    if (key.length !== 32) fail('Identity encryption is not configured.', 503);
    const {
      iv,
      tag,
      data
    } = JSON.parse(r.identity_cipher);
    const cipher = createDecipheriv('aes-256-gcm', key, Buffer.from(iv, 'hex'));
    cipher.setAuthTag(Buffer.from(tag, 'hex'));
    return JSON.parse(Buffer.concat([cipher.update(Buffer.from(data, 'hex')), cipher.final()]).toString());
  }
  const accountAccess = await accounts(db, {
    body,
    providers
  });
  for (const [column, definition] of [['identity_cipher', 'TEXT'], ['identity_status', "TEXT DEFAULT 'missing'"]]) if (!(await db.prepare('PRAGMA table_info(vendor_accounts)').all()).some(c => c.name === column)) await db.exec(`ALTER TABLE vendor_accounts ADD COLUMN ${column} ${definition}`);
  function encryptIdentity(p) {
    const iv = randomBytes(12),
      cipher = createCipheriv('aes-256-gcm', encryptionKey(), iv);
    const encrypted = Buffer.concat([cipher.update(JSON.stringify(p)), cipher.final()]);
    return JSON.stringify({
      iv: iv.toString('hex'),
      tag: cipher.getAuthTag().toString('hex'),
      data: encrypted.toString('hex')
    });
  }
  const market = await marketplace(db, {
    body,
    rider,
    getShipment,
    putShipment,
    append,
    jobView,
    providers,
    env
  });
  const router = async function route(req, res, url, send) {
    const path = url.pathname;
    if (await accountAccess.route(req, path, send)) return true;
    if (await market.route(req, path, send)) return true;
    if (path === '/api/accounts/identity' && req.method === 'POST') {
      const v = await accountAccess.vendor(req),
        r = v ? null : await rider(req),
        role = v ? 'vendor' : 'rider';
      if (!providers.identityReady) fail('Secure identity storage is not configured.', 503);
      const p = await body(req, 3000000),
        errors = validateIdentity(role, p);
      if (errors.length) fail(errors[0]);
      const image = p.idPhoto.match(/^data:image\/(png|jpeg);base64,([A-Za-z0-9+/=]+)$/),
        bytes = Buffer.from(image[2], 'base64');
      if (bytes.length > 2000000 || bytes.length < 8 || !(image[1] === 'png' ? bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) : bytes[0] === 255 && bytes[1] === 216)) fail('Use a valid JPG or PNG ID photo under 2 MB.');
      const identity = {
        fullName: p.fullName,
        idType: p.idType,
        idNumber: p.idNumber,
        idPhoto: p.idPhoto,
        homeAddress: p.homeAddress,
        submittedAt: new Date().toISOString(),
        ...(r ? {
          nin: p.nin,
          vehicle: p.vehicle,
          drivingLicence: p.idType === 'Driving licence' ? p.idNumber : p.drivingLicence || null,
          vehicleRegistration: p.vehicleRegistration || null,
          emergencyPhone: normalizePhone(p.emergencyPhone)
        } : {})
      };
      if (v) await db.prepare("UPDATE vendor_accounts SET identity_cipher=?,identity_status='submitted' WHERE id=?").run(encryptIdentity(identity), v.id);else await db.prepare("UPDATE rider_profiles SET identity_cipher=?,identity_status='submitted',identity_format=4,display_name=? WHERE id=?").run(encryptIdentity(identity), p.fullName, r.id);
      send(200, {
        status: 'submitted'
      });
      return true;
    }
    const vendorIdentity = path.match(/^\/api\/admin\/vendors\/([0-9a-f-]+)\/identity$/);
    if (vendorIdentity) {
      const provided = req.headers.authorization?.replace(/^Bearer /, '') || '';
      if (!env.TRACKSHIP_ADMIN_TOKEN || !equal(provided, env.TRACKSHIP_ADMIN_TOKEN)) fail('Operator access is required.', 403);
      const v = await db.prepare('SELECT * FROM vendor_accounts WHERE id=?').get(vendorIdentity[1]);
      if (!v?.identity_cipher) fail('Identity record not found.', 404);
      if (req.method === 'GET') {
        send(200, {
          ...decrypt(v),
          status: v.identity_status
        });
        return true;
      }
      if (req.method === 'POST') {
        const p = await body(req);
        if (!['approved', 'rejected'].includes(p.status)) fail('Choose approved or rejected.');
        await db.prepare('UPDATE vendor_accounts SET identity_status=? WHERE id=?').run(p.status, v.id);
        send(200, {
          status: p.status
        });
        return true;
      }
    }
    if (path === '/api/capabilities' && req.method === 'GET') {
      send(200, capabilities());
      return true;
    }
    if (path === '/api/auth/logout' && req.method === 'POST') {
      await body(req);
      const raw = req.headers.authorization?.match(/^Bearer ([a-f0-9]{64})$/)?.[1];
      if (raw) {
        await db.prepare('DELETE FROM vendor_sessions WHERE token_hash=?').run(digest(raw));
        await db.prepare('UPDATE workspaces SET disabled=1 WHERE token_hash=?').run(digest(raw));
      }
      if (raw && (await db.prepare('SELECT rider_id FROM rider_sessions WHERE token_hash=?').get(digest(raw)))) {
        const hash = digest(raw);
        await transaction(async () => {
          for (const row of await db.prepare('SELECT payload FROM shipments').all()) {
            const s = JSON.parse(row.payload);
            if (s.locationConsent?.sessionHash === hash) await putShipment({
              ...s,
              location: null,
              locationConsent: null
            });
          }
          await db.prepare('DELETE FROM rider_sessions WHERE token_hash=?').run(hash);
        });
      }
      send(200, {
        loggedOut: true
      });
      return true;
    }
    if (path === '/api/auth/request-otp' && req.method === 'POST') {
      const input = await body(req);
      const phone = normalizePhone(input.phone);
      if (!/^0[789]\d{9}$/.test(phone)) fail('Enter a valid Nigerian mobile phone.');
      if (!providers.smsReady) fail('SMS sign-in is not configured on this service.', 503);
      const recent = await db.prepare('SELECT created FROM auth_challenges WHERE phone=? ORDER BY created DESC LIMIT 1').get(phone);
      if (recent && Date.now() - recent.created < 60000) fail('Wait one minute before requesting another code.', 429);
      const id = randomUUID(),
        salt = token(),
        code = String(randomInt(100000, 1000000));
      await providers.sms(phone, `Your SendRack sign-in code is ${code}. It expires in 10 minutes. Do not share this sign-in code.`);
      await db.prepare('INSERT INTO auth_challenges(id,phone,salt,hash,expires,created) VALUES (?,?,?,?,?,?)').run(id, phone, salt, digest(salt + code), Date.now() + 600000, Date.now());
      send(200, {
        challengeId: id,
        expiresIn: 600
      });
      return true;
    }
    if (path === '/api/auth/verify-otp' && req.method === 'POST') {
      const input = await body(req);
      const c = await db.prepare('SELECT * FROM auth_challenges WHERE id=?').get(input.challengeId);
      if (!c || c.used || c.expires < Date.now() || c.attempts >= 5) fail('This code is expired or locked. Request a new code.', 401);
      await db.prepare('UPDATE auth_challenges SET attempts=attempts+1 WHERE id=?').run(c.id);
      if (!/^\d{6}$/.test(input.code || '') || !equal(digest(c.salt + input.code), c.hash)) fail('Incorrect sign-in code.', 401);
      const session = token();
      let r;
      await transaction(async () => {
        const current = await db.prepare('SELECT used FROM auth_challenges WHERE id=?').get(c.id);
        if (current.used) fail('This code has already been used.', 401);
        await db.prepare('UPDATE auth_challenges SET used=1 WHERE id=?').run(c.id);
        r = await db.prepare('SELECT * FROM rider_profiles WHERE phone=?').get(c.phone);
        if (!r) {
          const id = randomUUID();
          await db.prepare('INSERT INTO rider_profiles(id,phone,display_name) VALUES (?,?,?)').run(id, c.phone, 'Rider');
          r = await db.prepare('SELECT * FROM rider_profiles WHERE id=?').get(id);
        }
        await db.prepare('INSERT INTO rider_sessions VALUES (?,?,?)').run(digest(session), r.id, Date.now() + 30 * 86400000);
      });
      send(200, {
        token: session,
        profile: safeRider(r)
      });
      return true;
    }
    if (path === '/api/v3/rider/me' && req.method === 'GET') {
      send(200, safeRider(await rider(req)));
      return true;
    }
    if (['/api/v3/rider/identity', '/api/v4/rider/identity'].includes(path) && req.method === 'POST') {
      const r = await rider(req);
      if (!providers.identityReady) fail('Secure identity storage is not configured.', 503);
      const modern = path.includes('/v4/');
      const p = await body(req, modern ? 3000000 : 65536);
      let identity;
      if (modern) {
        if (!['National ID card', "Voter's card", 'Driving licence'].includes(p.idType) || typeof p.idNumber !== 'string' || !/^[A-Za-z0-9 /-]{5,40}$/.test(p.idNumber)) fail('Choose a government ID and enter its number.');
        if (p.idType === 'National ID card' && !/^\d{11}$/.test(p.idNumber)) fail('The national ID/NIN must contain 11 digits.');
        if (!['Bicycle', 'Motorcycle', 'Car', 'Van'].includes(p.vehicle)) fail('Choose a vehicle type.');
        const licence = p.idType === 'Driving licence' ? p.idNumber : p.drivingLicence;
        if (p.vehicle !== 'Bicycle' && (typeof licence !== 'string' || !/^[A-Za-z0-9 -]{5,30}$/.test(licence))) fail('A driving licence is required for motor vehicles, not vehicle registration.');
        const image = typeof p.idPhoto === 'string' ? p.idPhoto.match(/^data:image\/(png|jpeg);base64,([A-Za-z0-9+/=]+)$/) : null;
        if (!image) fail('Upload a JPG or PNG photograph of the ID.');
        const bytes = Buffer.from(image[2], 'base64');
        if (bytes.length > 2000000 || bytes.length < 8 || !(image[1] === 'png' ? bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) : bytes[0] === 255 && bytes[1] === 216)) fail('Use a valid JPG or PNG ID image under 2 MB.');
        identity = {
          idType: p.idType,
          idNumber: p.idNumber,
          idPhoto: p.idPhoto,
          drivingLicence: licence || null,
          vehicle: p.vehicle
        };
      } else {
        if (!/^\d{11}$/.test(p.nin || '') || typeof p.licence !== 'string' || !/^[A-Za-z0-9 -]{5,30}$/.test(p.licence)) fail('Enter NIN and driving licence number.');
        identity = {
          nin: p.nin,
          licence: p.licence
        };
      }
      if (typeof p.homeAddress !== 'string' || p.homeAddress.trim().length < 10 || p.homeAddress.length > 300 || typeof p.fullName !== 'string' || !p.fullName.trim() || p.fullName.length > 80 || !/^0[789]\d{9}$/.test(normalizePhone(p.emergencyPhone)) || p.consent !== true) fail('Enter your full legal name, home address, emergency contact and consent.');
      Object.assign(identity, {
        fullName: p.fullName,
        homeAddress: p.homeAddress,
        emergencyPhone: normalizePhone(p.emergencyPhone),
        submittedAt: new Date().toISOString()
      });
      const iv = randomBytes(12);
      const cipher = createCipheriv('aes-256-gcm', encryptionKey(), iv);
      const encrypted = Buffer.concat([cipher.update(JSON.stringify(identity)), cipher.final()]);
      await db.prepare("UPDATE rider_profiles SET display_name=?,identity_cipher=?,identity_status='submitted',identity_format=? WHERE id=?").run(p.fullName, JSON.stringify({
        iv: iv.toString('hex'),
        tag: cipher.getAuthTag().toString('hex'),
        data: encrypted.toString('hex')
      }), modern ? 4 : 1, r.id);
      send(200, {
        status: 'submitted',
        message: 'ID submitted securely for review. Submission does not mean verified.'
      });
      return true;
    }
    const admin = path.match(/^\/api\/admin\/riders\/([0-9a-f-]+)\/identity$/);
    if (admin) {
      const provided = req.headers.authorization?.replace(/^Bearer /, '') || '';
      if (!env.TRACKSHIP_ADMIN_TOKEN || !equal(provided, env.TRACKSHIP_ADMIN_TOKEN)) fail('Operator access is required.', 403);
      const r = await db.prepare('SELECT * FROM rider_profiles WHERE id=?').get(admin[1]);
      if (!r?.identity_cipher) fail('Identity record not found.', 404);
      if (req.method === 'GET') {
        send(200, {
          ...decrypt(r),
          status: r.identity_status
        });
        return true;
      }
      if (req.method === 'POST') {
        const input = await body(req);
        if (!['approved', 'rejected'].includes(input.status)) fail('Choose approved or rejected.');
        await db.prepare('UPDATE rider_profiles SET identity_status=? WHERE id=?').run(input.status, r.id);
        send(200, {
          status: input.status
        });
        return true;
      }
    }
    if (path === '/api/v3/shipments/snapshot' && req.method === 'POST') {
      const merchant = await owner(req);
      if (!merchant) fail('Business access is required.', 401);
      const input = await body(req);
      if (!Array.isArray(input.ids) || input.ids.length > 100 || input.ids.some(id => !uuid.test(id))) fail('Request at most 100 valid shipment references.');
      const select = db.prepare('SELECT payload FROM shipments WHERE id=? AND owner=?');
      const shipments = [];
      for (const id of new Set(input.ids)) {
        const row = await select.get(id, merchant);
        if (row) shipments.push(JSON.parse(row.payload));
      }
      send(200, {
        shipments
      });
      return true;
    }
    if (path === '/api/v3/shipments' && req.method === 'POST') {
      const merchant = await owner(req);
      if (!merchant) fail('Business access is required.', 401);
      const s = await body(req);
      const errors = validateTransport(s);
      if (errors.length) fail(errors[0]);
      if (!uuid.test(s.id) || !tokenPattern.test(s.publicToken || '') || !s.jobTokens || !tokenPattern.test(s.jobTokens.pickup || '') || s.deliveryType === 'interstate' && (!tokenPattern.test(s.jobTokens.carrier || '') || !tokenPattern.test(s.jobTokens.lastmile || ''))) fail('Invalid shipment references.');
      const existing = await db.prepare('SELECT owner,payload FROM shipments WHERE id=?').get(s.id);
      if (existing) {
        if (existing.owner !== merchant) fail('Shipment not found.', 404);
        send(200, JSON.parse(existing.payload));
        return true;
      }
      const fees = s.deliveryType === 'interstate' ? {
        pickup: feeKobo(s.pickupFee),
        carrier: feeKobo(s.carrierFee),
        lastmile: feeKobo(s.lastMileFee)
      } : {
        pickup: feeKobo(s.deliveryFee)
      };
      const at = new Date().toISOString();
      const tokens = s.deliveryType === 'interstate' ? {
        pickup: s.jobTokens.pickup,
        carrier: s.jobTokens.carrier,
        lastmile: s.jobTokens.lastmile
      } : {
        pickup: s.jobTokens.pickup
      };
      if (new Set(Object.values(tokens)).size !== Object.keys(tokens).length) fail('Each handler needs a distinct private dispatch token.');
      const stored = {
        ...s,
        id: s.id,
        code: `TS-${s.id.slice(0, 8).toUpperCase()}`,
        business: String(s.business || s.sender).slice(0, 80),
        workflowVersion: 3,
        status: 'Created',
        custodian: 'vendor',
        createdAt: at,
        actors: {},
        fees,
        jobTokens: tokens,
        payment: {
          status: 'unpaid',
          mode: null,
          amount: feeKobo(s.deliveryFee)
        },
        location: null,
        dirty: false,
        synced: true,
        events: [{
          id: randomUUID(),
          status: 'Created',
          actorName: String(s.business || s.sender).slice(0, 80),
          note: 'Shipment registered',
          at
        }]
      };
      await transaction(async () => {
        await db.prepare('INSERT INTO shipments(id,owner,public_hash,payload,rider_hash) VALUES (?,?,?,?,NULL)').run(s.id, merchant, digest(s.publicToken), JSON.stringify(stored));
        for (const [leg, raw] of Object.entries(tokens)) await db.prepare('INSERT INTO job_tokens VALUES (?,?,?)').run(digest(raw), s.id, leg);
      });
      await market.notify(stored, 'created');
      send(201, stored);
      return true;
    }
    const paymentRoute = path.match(/^\/api\/v3\/shipments\/([0-9a-f-]+)\/(pay|verify-payment)$/);
    if (paymentRoute && req.method === 'POST') {
      const merchant = await owner(req);
      if (!merchant) fail('Business access is required.', 401);
      const row = await db.prepare('SELECT payload FROM shipments WHERE id=? AND owner=?').get(paymentRoute[1], merchant);
      if (!row) fail('Shipment not found.', 404);
      const s = JSON.parse(row.payload);
      if (s.workflowVersion !== 3) fail('Create a new delivery to use the funded workflow.');
      if (!providers.paymentReady) fail('Paystack is not configured on this service.', 503);
      if (paymentRoute[2] === 'verify-payment') {
        const ref = s.payment.reference;
        if (!ref) fail('No payment has been started.', 404);
        const result = await providers.verify(ref);
        const updated = await verifyFunding(ref, result);
        await market.notify(updated, 'ready');
        send(200, {
          payment: updated.payment
        });
        return true;
      }
      const input = await body(req);
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.email || '') || input.email.length > 200) fail('Enter the payer’s email address.');
      if (s.payment.status === 'paid') {
        send(200, {
          payment: s.payment
        });
        return true;
      }
      const publicUrl = publicOrigin;
      if (!publicUrl || !publicUrl.startsWith('https://')) fail('A public HTTPS address must be configured before accepting payments.', 503);
      // Keep one active reference per delivery. Retrying initialization uses the same reference.
      let ref = s.payment.reference;
      if (!ref) {
        ref = 'TS-' + randomBytes(16).toString('hex');
        await transaction(async () => {
          const fresh = await getShipment(s.id);
          if (fresh.payment.reference) {
            ref = fresh.payment.reference;
            return;
          }
          await db.prepare('INSERT INTO payments(reference,shipment_id,amount,mode,status,provider_id,created) VALUES (?,?,?,?,?,?,?)').run(ref, s.id, s.payment.amount, providers.mode, 'pending', null, Date.now());
          await putShipment({
            ...fresh,
            payment: {
              ...fresh.payment,
              status: 'pending',
              reference: ref,
              mode: providers.mode
            }
          });
        });
      }
      const cached = await db.prepare('SELECT checkout_url FROM payments WHERE reference=?').get(ref);
      if (cached?.checkout_url) {
        send(200, {
          authorizationUrl: cached.checkout_url,
          reference: ref,
          mode: providers.mode
        });
        return true;
      }
      const result = await providers.initialize({
        email: input.email,
        amount: s.payment.amount,
        currency: 'NGN',
        reference: ref,
        callback_url: publicUrl + '/payment-return',
        metadata: {
          shipment_id: s.id
        }
      });
      const checkout = new URL(result.authorization_url);
      if (checkout.protocol !== 'https:' || !['checkout.paystack.com', 'standard.paystack.co'].includes(checkout.hostname)) fail('The payment provider returned an unexpected checkout address.', 502);
      await db.prepare('UPDATE payments SET checkout_url=? WHERE reference=?').run(checkout.href, ref);
      send(200, {
        authorizationUrl: checkout.href,
        reference: ref,
        mode: providers.mode
      });
      return true;
    }
    if (path === '/api/payments/webhook' && req.method === 'POST') {
      let raw = Buffer.alloc(0);
      for await (const chunk of req) {
        if (raw.length + chunk.length > 65536) fail('Webhook too large.', 413);
        raw = Buffer.concat([raw, chunk]);
      }
      const signature = req.headers['x-paystack-signature'];
      if (!providers.webhookKey || typeof signature !== 'string' || !equal(createHmac('sha512', providers.webhookKey).update(raw).digest('hex'), signature)) fail('Invalid payment signature.', 401);
      let event;
      try {
        event = JSON.parse(raw);
      } catch {
        fail('Invalid webhook.');
      }
      if (event.event === 'charge.success') {
        const ref = event.data?.reference;
        if (typeof ref !== 'string' || !(await db.prepare('SELECT reference FROM payments WHERE reference=?').get(ref))) {
          send(200, {
            received: true,
            ignored: true
          });
          return true;
        }
        const result = await providers.verify(ref);
        const paid = await verifyFunding(ref, result);
        await market.notify(paid, 'ready');
      }
      if (['transfer.success', 'transfer.failed', 'transfer.reversed'].includes(event.event)) {
        const ref = event.data?.reference;
        const item = await db.prepare('SELECT * FROM earnings WHERE transfer_ref=?').get(ref);
        if (item) {
          const verified = await providers.verifyTransfer(ref);
          if (verified.reference !== ref || verified.amount !== item.amount) fail('Transfer verification did not match.', 409);
          if (verified.status === 'success') await db.prepare("UPDATE earnings SET status='paid' WHERE id=?").run(item.id);else if (['failed', 'reversed'].includes(verified.status)) await db.prepare("UPDATE earnings SET status='review' WHERE id=?").run(item.id);
        }
      }
      send(200, {
        received: true
      });
      return true;
    }
    const jobs = path.match(/^\/api\/v3\/jobs\/([a-f0-9]{64})(?:\/(actions|location))?$/);
    if (jobs) {
      const r = await rider(req);
      const {
        s,
        leg
      } = await job(jobs[1]);
      if (req.method === 'GET' && !jobs[2]) {
        send(200, jobView(s, leg));
        return true;
      }
      if (req.method === 'POST' && jobs[2] === 'location') {
        const p = await body(req);
        const updated = await transaction(async () => {
          const fresh = await getShipment(s.id);
          if (fresh.actors?.[leg]?.id !== r.id || fresh.custodian !== leg || ['Delivered', 'Cancelled'].includes(fresh.status)) fail('Location sharing is allowed only for the rider currently carrying this parcel.', 403);
          if (p.stop === true) {
            const next = {
              ...fresh,
              location: null,
              locationConsent: null
            };
            await putShipment(next);
            return next;
          }
          if (p.start === true) {
            const next = {
              ...fresh,
              locationConsent: {
                actor: r.id,
                sessionHash: r.sessionHash,
                leg,
                at: new Date().toISOString()
              }
            };
            await putShipment(next);
            return next;
          }
          if (fresh.locationConsent?.actor !== r.id || fresh.locationConsent?.leg !== leg || fresh.locationConsent?.sessionHash !== r.sessionHash) fail('Start location sharing explicitly before uploading a position.', 403);
          if (typeof p.lat !== 'number' || typeof p.lng !== 'number' || !Number.isFinite(p.lat) || !Number.isFinite(p.lng) || p.lat < -90 || p.lat > 90 || p.lng < -180 || p.lng > 180 || !Number.isFinite(p.accuracy) || p.accuracy < 0 || p.accuracy > 5000) fail('Invalid GPS fix.');
          const next = {
            ...fresh,
            location: {
              lat: p.lat,
              lng: p.lng,
              accuracy: p.accuracy,
              at: new Date().toISOString(),
              leg
            }
          };
          await putShipment(next);
          return next;
        });
        send(200, {
          shared: Boolean(updated.locationConsent),
          at: updated.location?.at || null
        });
        return true;
      }
      if (req.method === 'POST' && jobs[2] === 'actions') {
        const input = await body(req);
        if (r.identity_status === 'missing' || r.identity_status === 'rejected') fail('Complete your secure rider identity details before accepting a parcel.', 403);
        if (s.payment.status !== 'paid') fail('The vendor must pay this delivery fee before dispatch.', 409);
        let spec = actionFor(s, leg);
        if (input.action === 'resend-otp' && s.status === 'Delivery OTP sent' && spec?.action === 'complete') spec = {
          ...spec,
          action: 'resend-otp'
        };
        if (s.status === 'Delivered' && input.action === 'complete') {
          send(200, jobView(s, leg));
          return true;
        }
        if (!spec || spec.action !== input.action) fail('This action does not match the parcel’s latest checkpoint.', 409);
        const isAccept = ['accept', 'accept-carrier', 'accept-lastmile'].includes(input.action);
        if (!isAccept && s.actors?.[leg]?.id !== r.id) fail('This parcel is assigned to another handler.', 403);
        if (['request-otp', 'resend-otp'].includes(input.action)) {
          const previous = await db.prepare('SELECT expires FROM delivery_proofs WHERE shipment_id=?').get(s.id);
          if (previous && Date.now() - (previous.expires - 600000) < 60000) fail('Wait one minute before resending the customer code.', 429);
          if (!providers.smsReady) fail('Customer OTP messages are not connected.', 503);
          const code = String(randomInt(100000, 1000000)),
            salt = token();
          await providers.sms(normalizePhone(s.phone), `Your SendRack delivery code is ${code}. Share it with your rider only after you have received parcel ${s.code}. It expires in 10 minutes.`);
          const updated = await transaction(async () => {
            const fresh = await getShipment(s.id);
            if (fresh.status !== s.status) fail('Shipment changed. Refresh and try again.', 409);
            await db.prepare('INSERT INTO delivery_proofs(shipment_id,salt,hash,expires,attempts,used) VALUES (?,?,?,?,0,0) ON CONFLICT(shipment_id) DO UPDATE SET salt=excluded.salt,hash=excluded.hash,expires=excluded.expires,attempts=0,used=0').run(s.id, salt, digest(salt + code), Date.now() + 600000);
            const next = input.action === 'resend-otp' ? fresh : append(fresh, spec.next, leg, r, 'Delivery code sent directly to the recipient');
            await putShipment(next);
            return next;
          });
          send(200, jobView(updated, leg));
          return true;
        }
        if (input.action === 'complete') {
          const proof = await db.prepare('SELECT * FROM delivery_proofs WHERE shipment_id=?').get(s.id);
          if (!proof || proof.used || proof.expires < Date.now() || proof.attempts >= 5) fail('The delivery code is expired or locked. Ask the vendor to arrange support.', 409);
          await db.prepare('UPDATE delivery_proofs SET attempts=attempts+1 WHERE shipment_id=?').run(s.id);
          if (!/^\d{6}$/.test(input.otp || '') || !equal(digest(proof.salt + input.otp), proof.hash)) fail('Incorrect customer delivery code.', 401);
          const updated = await transaction(async () => {
            const fresh = await getShipment(s.id);
            if (fresh.status === 'Delivered') return fresh;
            if (fresh.status !== 'Delivery OTP sent') fail('Delivery status changed. Refresh it.', 409);
            await db.prepare('UPDATE delivery_proofs SET used=1 WHERE shipment_id=? AND used=0').run(s.id);
            const next = append(fresh, 'Delivered', leg, r, 'Recipient confirmed possession with their private delivery code');
            await putShipment(next);
            await creditEarnings(next);
            return next;
          });
          await autoPayout(updated);
          send(200, jobView(updated, leg));
          return true;
        }
        const updated = await transaction(async () => {
          const fresh = await getShipment(s.id);
          if (fresh.status !== s.status) fail('Another handler updated this parcel. Refresh it.', 409);
          const assigned = isAccept ? {
            ...fresh,
            actors: {
              ...fresh.actors,
              [leg]: {
                id: r.id,
                name: r.display_name
              }
            }
          } : fresh;
          const next = append(assigned, spec.next, leg, r, String(input.note || '').slice(0, 240));
          await putShipment(next);
          return next;
        });
        send(200, jobView(updated, leg));
        return true;
      }
      fail('Method not allowed.', 405);
    }
    if (path === '/api/v3/rider/earnings' && req.method === 'GET') {
      const r = await rider(req);
      const entries = await db.prepare('SELECT id,shipment_id,leg,amount,mode,status FROM earnings WHERE rider_id=? ORDER BY created DESC,id DESC').all(r.id);
      send(200, {
        currency: 'NGN',
        entries,
        availableKobo: entries.filter(e => e.status === 'available').reduce((n, e) => n + e.amount, 0),
        paidKobo: entries.filter(e => e.status === 'paid').reduce((n, e) => n + e.amount, 0),
        testKobo: entries.filter(e => e.mode === 'test').reduce((n, e) => n + e.amount, 0),
        identityStatus: r.identity_status
      });
      return true;
    }
    if (path === '/api/v3/rider/payout-account' && req.method === 'POST') {
      const r = await rider(req);
      if (r.identity_status !== 'approved') fail('Identity review must be approved before connecting a payout account.', 403);
      if (!providers.paymentReady) fail('Payout provider is not connected.', 503);
      const p = await body(req);
      if (!/^\d{10}$/.test(p.accountNumber || '') || !/^\d{3,6}$/.test(p.bankCode || '')) fail('Enter your bank code and 10-digit account number.');
      const resolved = await providers.resolveAccount(p.accountNumber, p.bankCode);
      if (resolved.account_number !== p.accountNumber) fail('Account resolution failed.', 409);
      const recipient = await providers.recipient({
        type: 'nuban',
        name: resolved.account_name,
        account_number: p.accountNumber,
        bank_code: p.bankCode,
        currency: 'NGN'
      });
      if (!recipient.recipient_code) fail('Payout recipient could not be created.', 502);
      await db.prepare('UPDATE rider_profiles SET recipient_code=? WHERE id=?').run(recipient.recipient_code, r.id);
      send(200, {
        connected: true,
        accountName: resolved.account_name
      });
      return true;
    }
    if (path === '/api/v3/rider/withdraw' && req.method === 'POST') {
      const r = await rider(req);
      if (env.TRACKSHIP_ENABLE_PAYOUTS !== 'true') fail('Bank payouts are not activated by the operator.', 503);
      if (r.identity_status !== 'approved' || !r.recipient_code) fail('Approved identity and a connected payout account are required.', 403);
      for (const entry of await db.prepare("SELECT * FROM earnings WHERE rider_id=? AND status='available'").all(r.id)) await payoutEntry(entry);
      send(200, {
        submitted: true
      });
      return true;
    }
    return false;
  };
  router.ownerSession = accountAccess.owner;
  return router;
}
