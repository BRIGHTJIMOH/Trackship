import {execFileSync} from 'node:child_process';import {readFileSync} from 'node:fs';import {createHash} from 'node:crypto';import assert from 'node:assert/strict';
const version=readFileSync('android/firebase/build.gradle','utf8').match(/versionName '([^']+)'/)[1];
const apk=process.env.SENDRACK_TEST_APK||'artifacts/SendRack-'+version+'.apk';
const result=JSON.parse(execFileSync('python3',['-c',`import sys,zipfile,hashlib,json
with zipfile.ZipFile(sys.argv[1]) as z:
 names=['history.mjs','style.css','features.mjs','map-display.mjs','viewer-location.mjs','map-controls.css','vehicles.mjs','customer-wallet.mjs']
 dex=b''.join(z.read(n) for n in z.namelist() if n.endswith('.dex'))
 print(json.dumps({'files':{n:hashlib.sha256(z.read('assets/web/'+n)).hexdigest() for n in names},'illustration':hashlib.sha256(z.read('assets/web/assets/sendrack-courier-illustration.webp')).hexdigest(),'nativeAccountPush':all(n in dex for n in [b'configureAccountAlerts',b'open-account-alerts',b'SendRackPendingAlertRole',b'accountRole',b'tokenRefreshRequired']), 'nativeIllustrationPolicy':all(n in dex for n in [b'LocalAssetPolicy',b'/assets/sendrack-courier-illustration.webp']),'backend':z.read('assets/web/config.mjs').decode(),'nativeViewerBridge':all(n in dex for n in [b'requestViewerLocation',b'cancelViewerLocation',b'getCurrentLocation',b'ViewerLocation']), 'main':z.read('assets/web/sendrack-main.js').decode()}))`,apk],{encoding:'utf8'}));
for(const [name,sha]of Object.entries(result.files))assert.equal(sha,createHash('sha256').update(readFileSync('web/'+name)).digest('hex'),name+' differs from tested source');assert.match(result.backend,/https:\/\/sendrack-api\.onrender\.com/);assert.equal(result.nativeViewerBridge,true);assert.equal(result.main,readFileSync('web/app.js','utf8').replaceAll('0.7.0',version));
console.log('APK package check passed: exact tested viewer/map modules and CSS, current app source, compiled native bridge and unchanged Render backend URL. This is not Android OS execution.');

assert.equal(result.illustration,createHash('sha256').update(readFileSync('web/assets/sendrack-courier-illustration.webp')).digest('hex'));assert.equal(result.nativeIllustrationPolicy,true);assert.match(readFileSync('android/src/ng/trackship/app/MainActivity.java','utf8'),/LocalAssetPolicy\.allowed\(p\)/);

assert.equal(result.nativeAccountPush,true,'compiled role-aware notifications and token refresh must be in the signed APK');
